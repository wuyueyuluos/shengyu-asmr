在 app/src/main/AndroidManifest.xml 的 <application ...> 中加入：
    android:icon="@mipmap/ic_launcher"
    android:roundIcon="@mipmap/ic_launcher_round"

将本压缩包内所有资源文件夹合并到 app/src/main/res/。
注意：旧版 Android 使用 mipmap-* 中的 ic_launcher.png；Android 8.0 及以上使用 mipmap-anydpi-v26 的自适应图标。
